import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DropDown {
    private JComboBox<String> foreignKeyComboBox;

    public DropDown() {
        JFrame frame = new JFrame("Foreign Key Drop-Down");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        foreignKeyComboBox = new JComboBox<>();

        JButton selectButton = new JButton("Select");
        selectButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                selectData();
            }
        });

        JPanel panel = new JPanel();
        panel.add(new JLabel("Foreign Key:"));
        panel.add(foreignKeyComboBox);
        panel.add(selectButton);

        frame.getContentPane().add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    public void populateComboBox() {
        String url = "jdbc:oracle:thin:@localhost:1521:ORCL";
        String username = "your_username";
        String password = "your_password";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String sql = "SELECT id, name FROM your_table_name";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                foreignKeyComboBox.addItem(id + ": " + name);
            }

            resultSet.close();
            statement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error occurred while populating the drop-down.");
        }
    }

    public void selectData() {
        String selectedValue = foreignKeyComboBox.getSelectedItem().toString();
        int selectedId = Integer.parseInt(selectedValue.split(":")[0].trim());

        JOptionPane.showMessageDialog(null, "Selected ID: " + selectedId);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                DropDown app = new DropDown();
                app.populateComboBox();
            }
        });
    }
}